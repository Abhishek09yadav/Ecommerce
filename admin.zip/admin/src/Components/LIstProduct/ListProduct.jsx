import React from 'react';
import './ListProduct.css'

function ListProduct(props) {
    return (
        <div className={'ListProduct'}>


        </div>
    );
}

export default ListProduct;