import React from 'react';
import './AddProduct.css'

function AddProduct(props) {
    return (
        <div className="AddProduct">
            <div className="AddProduct-itemfield">
                <p>
                    Product Title
                </p>
                <input type='text' name='name' placeholder='Product Title'/>
            </div>
        </div>
    );
}

export default AddProduct;